# Super Fast YouTube to MP3/MP4 Converter API

A simple way to convert Youtube videos to mp3/mp4 using API service. Get quality like 320 kbps, 256 kbps, 192 kbps, 128 kbps mp3 format for all devices.

Conversion is instant even in seconds for hours lenght videos no wait.

Update: Now you can convert country & age restricted music videos like http://kworb.net/youtube/topvideos_restricted.html

Here is a simple auto responsive[For All Devices] iframe code to easily embed to your websites and enjoy best ever converter for free.

MP3 Converter API Code(Single Button):

```<iframe src="https://youtube2mp3api.com/@api/button/mp3/YouTube-Video-ID" width="100%" height="35px" scrolling="no" style="border:none;"></iframe>```

MP3 Converter API Code:

```<iframe src="https://www.yt-download.org/@api/button/mp3/YouTube-Video-ID" width="100%" height="100px" scrolling="no" style="border:none;"></iframe>```

MP4, WEbM, 3Gp & Flv Video Converter API Code:

```<iframe src="https://www.yt-download.org/@api/button/videos/YouTube-Video-ID" width="100%" height="100px" scrolling="no" style="border:none;"></iframe>```

Please replace YouTube-Video-ID with dynamic video id value.

Please write to us for any query or support : yt2mp3.ws@gmail.com

Official API Website: https://www.yt2mp3.ws/developers/ OR https://youtube2mp3api.com/
